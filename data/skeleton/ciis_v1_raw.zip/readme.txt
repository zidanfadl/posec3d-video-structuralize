Github file size limit: 25Mb

Raw file size: 1.8 Gb

GDrive ciis_v1_raw: https://drive.google.com/drive/folders/1PHpVwPAQ868Wki09-RN38lGHC9CS0Wcg
